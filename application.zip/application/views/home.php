<section style="min-height: calc(100vh - 83px);" class="light-bg">
	<div class="container">
		
        <div class="row">
			<div class="col-lg-offset-3 col-lg-6 text-center">
				<div class="section-title">
					<h2>PAINEL DE ADMINISTRADOR</h2>
				</div>
			</div>
		</div>

        <div class="row">
			<div class="col-lg-offset-5 col-lg-2 text-center">
				<div class="form-group">
                    <a class="btn btn-link" href="<?php base_url(); ?>exit"><i class="fa fa-sign-out"></i></a>
				</div>
			</div>
		</div>
	</div>
    <div class="container">
        <ul class="nav nav-tabs">
            <li class="active"><a href="#tab_alunos" role="tab" data-toggle="tab">Alunos</a></li>
        </ul>

        <div class="tab-content">
            <div id="tab_alunos" class="tab-pane active">
                
            </div>
        </div>
    </div>
</section>

<div id="modal_aluno" class="modal fade">
</div>