<footer>
	<div class="container text-center">
		<p>Feito por <span>Gabriel Henrique Martins</span></p>
	</div>
</footer>